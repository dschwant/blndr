>>>>>> LuBan settings <<<<<<
Method: Hash
Unit:   mm
Model size X: 164.553
Model size Y: 73.3087
Model size Z: 223.842
Sheet width:     200
Sheet height:    250
Sheet thickness: 5
Nesting: ordered
Tolerance:            0.2
Orthogonal or radial: 1
Radial center x:      0
Radial center y:      0
Ring width:           15
X layer:              18
Z layer:              13
Tilt:                 -8
Text size:            0.03
Parts:         46
Machine time:  23 min
Assembly time: 1.3 h
Total time:    1.7 h

2D assembly files are stored in the Asm_* folders.
3D assembly is stored in the Asm3D.* files.
Cutting files are stored in the Cut_* folders.
The unit of the cutting data is millimeter.
3D printing files are stored in the Print folder.

DXF and SVG format can be read by most CAD software.
FGS native format can be read by 3D window.
SHP native format can be read by 2D window.
